#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  3 14:58:24 2020

@author: alexandre
"""

from wombat import *

# Problem parameters
Yg_mod = 35*10**9.
Nu_poi = 0.2
h=15
patm = 10**5
g = 9.81
FLoad =  0.5 * 1000 * g * h

# Geometry description and mesh generation
mesh, boundary = call_gmsh('geometry/wing1.geo',SolidT3)
left = boundary.get_elem_from_tag("left")
down = boundary.get_elem_from_tag("down")

# Material properties
mat = LinearElastic(E=Yg_mod,nu=Nu_poi,model = "plane_stress")

# Boundary conditions and load
appuis = Connections()
appuis.add_imposed_displ(down,ux=0,uy=0)

forces = ExtForce()
forces.add_distributed_forces(left, fx=FLoad)

# Model construction
model = Model(mesh,mat)

# Assembly phase
K = assembl_stiffness_matrix(model)
L,Ud = assembl_connections(appuis,model)
F = assembl_external_forces(forces,model)

# Solving
U,lamb = solve(K,F,L,Ud)

# Post-processing

list_res = specific_res_treat()

nbFig = 1
coeff = 0.5
analysis_type=mat.model
list_res.treat_stat(mesh)
nbFig = list_res.treat_disp(mesh,coeff,U,appuis,analysis_type,nbFig)
nbFig = list_res.treat_stress(mesh,coeff,U,model,analysis_type,nbFig)

