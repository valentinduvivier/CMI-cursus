#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  4 16:55:43 2020

@author: alexandre
"""

from wombat import *

# Problem parameters
Yg_mod = 135  *10**9
Nu_poi = 0.35
h      = 15   *10**(-2)
a      = 2.5  *10**(-2)
fs     = 1    *10**6


# Geometry description and mesh generation
mesh, boundary = call_gmsh('geometry/PlateHole.geo',SolidT6)
left = boundary.get_elem_from_tag("left")
right = boundary.get_elem_from_tag("right")
top = boundary.get_elem_from_tag("top")
bottom = boundary.get_elem_from_tag("bottom")
center = boundary.get_elem_from_tag("center")
dam = mesh.get_elem_from_tag("plate")

# Material properties
mat = LinearElastic(E=Yg_mod,nu=Nu_poi,model = "plane_stress")

# Boundary conditions and load
appuis = Connections()
appuis.add_imposed_displ(bottom,  uy=0)


forces = ExtForce()
forces.add_distributed_forces(top ,   fy =  fs)
forces.add_distributed_forces(bottom, fy = -fs)

# Model construction
model = Model(mesh,mat)

# Assembly phase
K = assembl_stiffness_matrix(model)
L,Ud = assembl_connections(appuis,model)
F = assembl_external_forces(forces,model)

# Solving
U,lamb = solve(K,F,L,Ud)

# Post-processing

list_res = specific_res_treat()

nbFig = 1
coeff = 0.5
analysis_type=mat.model
list_res.treat_stat(mesh)
nbFig = list_res.treat_disp(mesh,coeff,U,appuis,analysis_type,nbFig)
nbFig = list_res.treat_stress(mesh,coeff,U,model,analysis_type,nbFig)
# Potential energy
Ep0=list_res.treat_potential_energy(U,K,F)
