import numpy as np
import matplotlib.pyplot as plt 

# Parameters 
fs     = 1    *10**6
a      = 0.025
L      = 0.4

# Polar coordinates 
R = np.linspace(a,L,50)
Theta = np.linspace(0,np.pi,50)

# Meshgrid of polar coordiantes

r,theta = np.meshgrid(R,Theta)

def sig_rr(r,theta):
    return fs/2*(1-(a*a)/(r*r))+fs/2*(1-(4*a*a)/(r*r)+(3*a**4)/(r**4))*np.cos(2*(theta-np.pi/2))

def sig_tt(r,theta):
    return fs/2*(1-(a*a)/(r*r))-fs/2*(1+(3*a**4)/(r**4))*np.cos(2*(theta-np.pi/2))

def sig_rt(r,theta):
    return fs/2*(1-(a*a)/(r*r))-fs/2*(1-(3*a**4)/(r**4)+(2*a*a)/(r*r))*np.sin(2*(theta-np.pi/2))

sig_rr_verti = sig_rr(R,theta=np.pi/2)
sig_tt_verti = sig_tt(R,theta=np.pi/2)
sig_rt_verti = sig_rt(R,theta=np.pi/2)

plt.figure()
plt.plot(R, sig_rr_verti)
plt.xlabel('r (m)')
plt.ylabel('strain (Pa)')
plt.title('sigma rr verti')
plt.show()

plt.figure()
plt.plot(R, sig_tt_verti)
plt.xlabel('r (m)')
plt.ylabel('strain (Pa)')
plt.title('sigma theta theta verti')
plt.show()

plt.figure()
plt.plot(R, sig_rt_verti)
plt.xlabel('r (m)')
plt.ylabel('strain (Pa)')
plt.title('sigma r theta verti')
plt.show()

sig_rr_hori = sig_rr(R,theta=0)
sig_tt_hori = sig_tt(R,theta=0)
sig_rt_hori = sig_rt(R,theta=0)

plt.figure()
plt.plot(R, sig_rr_hori)
plt.xlabel('r (m)')
plt.ylabel('strain (Pa)')
plt.title('sigma rr hori')
plt.show()

plt.figure()
plt.plot(R, sig_tt_hori)
plt.xlabel('r (m)')
plt.ylabel('strain (Pa)')
plt.title('sigma theta theta hori')
plt.show()


plt.figure()
plt.plot(R, sig_rt_hori)
plt.xlabel('r (m)')
plt.ylabel('strain (Pa)')
plt.title('sigma r theta hori')
plt.show()
