import numpy as np
import pylab as plt
import scipy.linalg
from scipy import special
from scipy.integrate import odeint
from scipy.signal import chirp, find_peaks, peak_widths


def ode_coef_unsteady(cfg, tau):
    
    """ %--------------------------------------------------------------------------
        % PURPOSE:   Compute the time-dependent parameters f(t) and g(t)
        %--------------------------------------------------------------------------
    """
    
    # Compute the time-dependent parameters f(t) and g(t) (ok)
    f  = 2/cfg.mu*((0.5-cfg.a_h)*cfg.a0_deg*np.pi/180+cfg.h0)*(cfg.psi_1*cfg.eps_1*np.exp(-cfg.eps_1*tau) \
                                          +cfg.psi_2*cfg.eps_2*np.exp(-cfg.eps_2*tau))        
    g  =-(1+2*cfg.a_h)/(2.*cfg.r_a**2)*(2/cfg.mu*((0.5-cfg.a_h)*cfg.a0_deg*np.pi/180+cfg.h0)*\
        (cfg.psi_1*cfg.eps_1*np.exp(-cfg.eps_1*tau)+cfg.psi_2*cfg.eps_2*np.exp(-cfg.eps_2*tau))) 
    return f, g


def ode_coef_CD(cfg):
    
    """ % --------------------------------------------------------------------------
        % PURPOSE:   WRITE the aeroelastic system in the form of a 2nd order ODE.
        %            In the case of non-linearities of the stifness matrix, the system of governing equations reads:
        %
        %    c0*ddxi+c1*ddalpha+c2*dxi+c3*dalpha+c4*xi+c5*alpha+c6*w1+c7*w2+c8*w3+c9*w4+c10*G(xi   ) = f(tau)
        %    d0*ddxi+d1*ddalpha+d2*dxi+d3*dalpha+d4*xi+d5*alpha+d6*w1+d7*w2+d8*w3+d9*w4+d10*M(alpha) = g(tau)
        %
        %    f and g are functions of time
        % --------------------------------------------------------------------------
    """
    
    C=np.zeros(11)
    D=np.zeros(11)   

    C[0] = 1+1/cfg.mu
    C[1] = cfg.x_a - cfg.a_h/cfg.mu
    C[2] = 2*(1-cfg.psi_1-cfg.psi_2)/cfg.mu + 2*cfg.zeta_h*cfg.omgb/cfg.U_star
    C[3] =(1+(1-2*cfg.a_h)*(1-cfg.psi_1-cfg.psi_2))/cfg.mu
    C[4] = 2*(cfg.eps_1*cfg.psi_1+cfg.eps_2*cfg.psi_2)/cfg.mu
    C[5] = 2*(1-cfg.psi_1-cfg.psi_2+(0.5-cfg.a_h)*(cfg.eps_1*cfg.psi_1+cfg.eps_2*cfg.psi_2))/cfg.mu
    C[6]= 2*cfg.eps_1*cfg.psi_1*(1-cfg.eps_1*(0.5-cfg.a_h))/cfg.mu
    C[7] = 2*cfg.eps_2*cfg.psi_2*(1-cfg.eps_2*(0.5-cfg.a_h))/cfg.mu
    C[8] =-2*cfg.eps_1**2*cfg.psi_1/cfg.mu
    C[9] =-2*cfg.eps_2**2*cfg.psi_2/cfg.mu
    C[10] = (cfg.omgb/cfg.U_star)**2
    
    D[0] = (cfg.x_a-cfg.a_h/cfg.mu)/cfg.r_a**2
    D[1] =  1+(1+8*cfg.a_h**2)/(8.*cfg.mu*cfg.r_a**2)
    D[2] = -(1+2*cfg.a_h)*(1-cfg.psi_1-cfg.psi_2)/(cfg.mu*cfg.r_a**2)
    D[3] = ((1-2*cfg.a_h)-(1+2*cfg.a_h)*(1-2*cfg.a_h)*(1-cfg.psi_1-cfg.psi_2))\
           /(2*cfg.mu*cfg.r_a**2)+2*cfg.zeta_a/cfg.U_star
    D[4] = -(1+2*cfg.a_h)*(cfg.eps_1*cfg.psi_1+cfg.eps_2*cfg.psi_2)/(cfg.mu*cfg.r_a**2)
    D[5] = -(2*(1+2*cfg.a_h)*(1-cfg.psi_1-cfg.psi_2)+(1+2*cfg.a_h)*(1-2.*cfg.a_h)\
           *(cfg.psi_1*cfg.eps_1-cfg.psi_2*cfg.eps_2))/(2.*cfg.mu*cfg.r_a**2)
    D[6] = -(1+2*cfg.a_h)*cfg.psi_1*cfg.eps_1*(1-cfg.eps_1*(0.5-cfg.a_h))/(cfg.mu*cfg.r_a**2)
    D[7] = -(1+2*cfg.a_h)*cfg.psi_2*cfg.eps_2*(1-cfg.eps_2*(0.5-cfg.a_h))/(cfg.mu*cfg.r_a**2)
    D[8] = (1+2*cfg.a_h)*cfg.psi_1*cfg.eps_1**2/(cfg.mu*cfg.r_a**2)
    D[9] = (1+2*cfg.a_h)*cfg.psi_2*cfg.eps_2**2/(cfg.mu*cfg.r_a**2)
    D[10] = 1/cfg.U_star**2
    return C, D


def compute_RHS(q, tau, cfg, q0):
    
    """ Return the rhs f= [f0,...f7] of the fisrt-order EDO of the nonlinear PAPA system (Eq. 13)
    
        Comment : the ordering of the unknown vector x is:
        x[0:7] = [x1   , x2    , x3,  x4, x5, x6, x7, x8]^T  
               = [alpha, dalpha, xi, dxi, w1, w2, w3, w4]^T    
    """    
    
    # compute the coefficients of the 2nd order ODE (ok)
    [C, D] = ode_coef_CD(cfg)
    #D = ode_coef_D()

    # Compute the time-dependent parameters f(t) and g(t) (ok)
    [f, g] = ode_coef_unsteady(cfg, tau)
    #f  = 2/cfg.mu*((0.5-cfg.a_h)*init[0]+init[2])*(cfg.psi_1*cfg.eps_1*np.exp(-cfg.eps_1*tau) \
    #                                      +cfg.psi_2*cfg.eps_2*np.exp(-cfg.eps_2*tau))        
    #g  =-(1+2*cfg.a_h)/(2.*cfg.r_a**2)*(2/cfg.mu*((0.5-cfg.a_h)*init[0]+init[2])*\
    #    (cfg.psi_1*cfg.eps_1*np.exp(-cfg.eps_1*tau)+cfg.psi_2*cfg.eps_2*np.exp(-cfg.eps_2*tau))) 

    # Compute the linear terms of the ODE (ok)
    P =  C[2]*q[3] + C[3]*q[1] + C[4]*q[2] + C[5]*q[0] + C[6]*q[4] + C[7]*q[5] + C[8]*q[6] + C[9]*q[7] - f
    H =  D[2]*q[3] + D[3]*q[1] + D[4]*q[2] + D[5]*q[0] + D[6]*q[4] + D[7]*q[5] + D[8]*q[6] + D[9]*q[7] - g
        
    # Polynomial nonlinearities (ok)
    K_h = cfg.kh_c1*q[2] + cfg.kh_c3*np.power(q[2],3) + cfg.kh_c5*np.power(q[2],5)
    K_a = cfg.ka_c1*q[0] + cfg.ka_c3*np.power(q[0],3) + cfg.ka_c5*np.power(q[0],5)

    # Assemble the rhs in dqdt=rhs for the unknown: 
    # q(0:7) = [alpha, dalpha, xi, dxi, w1, w2, w3, w4],   rq. [alpha]=rad; [dalpha]=rad/s
    rhs    =  np.zeros(8)       # a column vector (with 8 lines)
    rhs[0] =  q[1]
    rhs[1] = (+C[0]*(H+D[10]*K_a) - D[0]*(P+C[10]*K_h) )/ (D[0]*C[1]-D[1]*C[0])
    rhs[2] =  q[3]
    rhs[3] = (-C[1]*(H+D[10]*K_a) + D[1]*(P+C[10]*K_h) )/ (D[0]*C[1]-D[1]*C[0])
    rhs[4] =  q[0] - cfg.eps_1*q[4]
    rhs[6] =  q[2] - cfg.eps_1*q[6]
    rhs[5] =  q[0] - cfg.eps_2*q[5]
    rhs[7] =  q[2] - cfg.eps_2*q[7]
    
    return rhs

def solve_LCO_PAPA_V_flutter(cfg):
        
    """ Main program for the time-domain LCO solution of the nonlinear PAPA 
    system with polynomial restoring forces in pitch.
    """
    
    # the size of the time-step is prescribed by the user
    nbstp  = int(cfg.tau_max / cfg.time_step)

    # Allocate tables
    time   = np.linspace(0, cfg.tau_max, num=nbstp)
    pitch  = np.zeros(nbstp)
    dpitch = np.zeros(nbstp)
    plung  = np.zeros(nbstp)
    dplung = np.zeros(nbstp)

    # Initial Conditions:  = [alpha, dalpha, xi, dxi, w1, w2, w3, w4]^T
    q0  = np.array([cfg.a0_deg*np.pi/180., cfg.da0_deg*np.pi/180, cfg.h0, cfg.dh0, 0, 0, 0, 0,]); 

    # Time integration
    sol = odeint(compute_RHS, q0, time, args=(cfg, q0))

    # Get time histories of the unknowns of interest
    pitch [:] = sol[:,0]/np.pi*180.  # pitch displacement in deg.
    dpitch[:] = sol[:,1]/np.pi*180.
    plung [:] = sol[:,2]
    dplung[:] = sol[:,3]
    # 4 others sol[:,i] are zero as w_i=0
    
    #print('Normal end of execution',cfg.U_star)
    #print('Running airspeed index:',cfg.U_star)
    
    return [time, pitch, dpitch, plung, dplung, np.real(sol[-1,:]), np.imag(sol[-1,:])]

def solve_LCO_PAPA(cfg):
    
    """ Main program for the time-domain LCO solution of the nonlinear PAPA 
    system with polynomial restoring forces in pitch.
    """
    
    # the size of the time-step is prescribed by the user
    nbstp = np.int(cfg.tau_max/cfg.time_step)

    # Allocate tables
    time =  np.linspace(0, cfg.tau_max, num=nbstp)
    pitch = np.zeros(nbstp)
    dpitch= np.zeros(nbstp)
    plung = np.zeros(nbstp)
    dplung= np.zeros(nbstp)

    # Initial Conditions:  = [alpha, dalpha, xi, dxi, w1, w2, w3, w4]^T
    q0 = np.array([cfg.a0_deg*np.pi/180., cfg.da0_deg*np.pi/180, cfg.h0, cfg.dh0, 0, 0, 0, 0,]); 

    # Time integration
    sol = odeint(compute_RHS, q0, time, args=(cfg, q0))

    # Get time histories of the unknowns of interest
    pitch  [:] = sol[:,0]/np.pi*180.  # pitch displacement in deg.
    dpitch [:] = sol[:,1]/np.pi*180.
    plung  [:] = sol[:,2]
    dplung [:] = sol[:,3]
    
    #print('Normal end of execution',cfg.U_star)
    #print('Running airspeed index:',cfg.U_star)

    return [time, pitch, dpitch, plung, dplung]

def plot_time_histories(time, pitch, dpitch, plung, dplung):
    
    fig1=plt.figure(figsize=(20,10))
    
    plt.subplot(2, 4, 1)
    
    plt.plot(time[:], pitch[:], '-')

    plt.xlabel('dimensionless time')
    plt.ylabel('Pitch (deg)')
    
    plt.axis([1000, 2000, -10, 10]) 

    plt.grid(True)

    # -------
    
    plt.subplot(2,4,2)
    
    plt.plot(pitch[:], dpitch[:], '-')
    
    plt.title('LCO of 2DOF PAPA incompressible system with polynomial nonlinearity in pitch')
    plt.xlabel('pitch angle') 
    plt.ylabel('pitching rate')
    
    plt.grid(True)

    # -------

    plt.subplot(2,4,3)
    
    plt.plot(time[:],plung[:]   ,'-')
    
    plt.xlabel('dimensionless time')
    plt.ylabel('plunge rate')
    
    plt.grid(True)

    # -------

    plt.subplot(2,4,4)
    
    plt.plot(plung[:], dplung[:], '-')
    
    plt.xlabel('plunge')
    plt.ylabel('plunging rate')
    
    plt.grid(True)

def get_LCO_amp2(pitch, nb_peaks_retained):
    
    """
    """
    
    ind_peaks, _   = find_peaks(pitch)
    ind_valleys, _ = find_peaks(-pitch)

    # take the mean value of last pitch amplitude of the peaks : nb_peaks_retained
    pitch_lco_max = pitch[ind_peaks[len(ind_peaks)-nb_peaks_retained-1:len(ind_peaks)-1]]
    pitch_lco_min = pitch[ind_valleys[len(ind_valleys)-nb_peaks_retained-1:len(ind_valleys)-1]]
    
    # arrondi les elements de pitch_lco_max à la seconde decimale puis elimine les doublons
    pitch_lco_max_red = np.unique(np.round(pitch_lco_max[:],2))
    pitch_lco_min_red = np.unique(np.round(pitch_lco_min[:],2))
    nb_pmax = len(pitch_lco_max_red)
    nb_pmin = len(pitch_lco_min_red)
    
    return [nb_pmin, pitch_lco_min_red, nb_pmax, pitch_lco_max_red] 

def Compute_Bifurcation_Map(U_min, U_max, nbrun, cfg, nb_peaks_retained):
    
    ''' Compute the bifurcation map of the PAPA system
        Input : U_min, U_max, nbrun, cfg
        Output: plot_speed[], pitch_lco[]'''
    
    speed_index = np.linspace(U_min, U_max, num=nbrun)*cfg.Vf
    pitch_lco   = np.zeros(nbrun*nb_peaks_retained)
    plot_speed  = np.zeros((nbrun*nb_peaks_retained), dtype=float)
    
    #nb_peaks_retained = 10
    cpt = 0

    for l in range (0, nbrun):
        cfg.U_star  = speed_index[l]
        print('run #',l+1, end="\r")
    
        [time, pitch, dpitch, plung, dplung]  = solve_LCO_PAPA(cfg)
    
        [nb_pmin, pitch_lco_min_red, nb_pmax, pitch_lco_max_red]  = get_LCO_amp2(pitch, nb_peaks_retained)
    
        for i in range(0, nb_pmin):
            pitch_lco [cpt] = pitch_lco_min_red[i]
            plot_speed[cpt] = cfg.U_star
            cpt = cpt+1
            
        for i in range(0, nb_pmax):
            pitch_lco [cpt] = pitch_lco_max_red[i]
            plot_speed[cpt] = cfg.U_star
            cpt = cpt+1
        
    print('task done.')
    
    return plot_speed, pitch_lco, cpt

def Compute_Bifurcation_Map_plung(U_min, U_max, nbrun, cfg, nb_peaks_retained):
    
    '''Compute the bifurcation map of the PAPA system
       Input : U_min, U_max, nbrun, cfg
       Output: plot_speed[], plung_lco[]
    '''
    
    speed_index = np.linspace(U_min, U_max, num=nbrun)*cfg.Vf
    plung_lco   = np.zeros(nbrun*nb_peaks_retained)
    plot_speed  = np.zeros((nbrun*nb_peaks_retained), dtype=float)

    #nb_peaks_retained = 10
    cpt = 0

    STOCK_cpt = np.zeros((2, nbrun))
    
    for l in range(0, nbrun):
        cfg.U_star  = speed_index[l]
        print('run #',l+1, end="\r")
    
        [time, pitch, dpitch, plung, dplung] = solve_LCO_PAPA(cfg)
    
        [nb_pmin, plung_lco_min_red, nb_pmax, plung_lco_max_red]  = get_LCO_amp2(plung, nb_peaks_retained)

        for i in range(0, nb_pmin):
            plung_lco [cpt]  = plung_lco_min_red[i]
            plot_speed[cpt]  = cfg.U_star
            cpt = cpt+1
            
#         STOCK_cpt[0,l] = int(cpt)
        
        for i in range(0, nb_pmax):
            plung_lco [cpt] = plung_lco_max_red[i]
            plot_speed[cpt] = cfg.U_star
            cpt = cpt+1

#         STOCK_cpt[1,l] = cpt

    print('task done.')
    
    return plot_speed, plung_lco, cpt