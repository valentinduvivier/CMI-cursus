#!/usr/bin/env python3
import glob, os, sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ------------------------------------------------------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

gamma = 1.4
rinf  = 1.0
pinf  = 1e5
uinf  = np.sqrt(pinf/rinf)

# ------------------------------------------------------------------------------
# extract data

x1, ro1, rou1, rov1, roE1 = np.loadtxt( fname='restart0000_2000_k2_0.dat', unpack=True )
x2, ro2, rou2, rov2, roE2 = np.loadtxt( fname='restart0000_2000_k2_1.dat', unpack=True )
x3, ro3, rou3, rov3, roE3 = np.loadtxt( fname='restart0000_2000_k2_2.dat', unpack=True )
legends=[r'$k_2=0$',r'$k_2=1$',r'$k_2=2$']

u1 = rou1/ro1
u2 = rou2/ro2
u3 = rou3/ro3
p1 = (gamma-1)*(roE1 - 0.5*ro1*u1**2)
p2 = (gamma-1)*(roE2 - 0.5*ro2*u2**2)
p3 = (gamma-1)*(roE3 - 0.5*ro3*u3**2)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)


# ------------------------------------------------------------------------------
# rho
fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
ax.plot(x_ex, r_ex, color='grey', ls='-', label='analytical')
ax.plot(x1, ro1/rinf, ls='--', label=legends[0])
ax.plot(x2, ro2/rinf, ls='--', label=legends[1])
ax.plot(x3, ro3/rinf, Ls='--', label=legends[2])

ax.set_xlabel(r'$x$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()

plt.savefig("shock_tube_rho.png")

# ------------------------------------------------------------------------------
# pressure
fig2 = plt.figure(2,figsize=(8,6))
ax = fig2.add_subplot(111)
ax.plot(x_ex, p_ex, color='grey', ls='-', label='analytical')
ax.plot(x1, p1/pinf, ls='--', label=legends[0])
ax.plot(x2, p2/pinf, ls='--', label=legends[1])
ax.plot(x3, p3/pinf, Ls='--', label=legends[2])

ax.set_xlabel(r'$x$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()

plt.savefig("shock_tube_pressure.png")

# ------------------------------------------------------------------------------
# pressure
fig3 = plt.figure(3,figsize=(8,6))
ax = fig3.add_subplot(111)
ax.plot(x_ex, u_ex, color='grey', ls='-', label='analytical')
ax.plot(x1, u1/uinf, ls='--', label=legends[0])
ax.plot(x2, u2/uinf, ls='--', label=legends[1])
ax.plot(x3, u3/uinf, Ls='--', label=legends[2])

ax.set_xlabel(r'$x$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()

plt.savefig("shock_tube_velocity.png")
