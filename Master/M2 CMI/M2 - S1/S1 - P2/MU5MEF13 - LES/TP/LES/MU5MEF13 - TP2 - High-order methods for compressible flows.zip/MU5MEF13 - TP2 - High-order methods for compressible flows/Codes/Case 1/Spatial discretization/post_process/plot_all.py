#!/usr/bin/env python3
import glob, os, sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

"""for i in ["02","04","06","08","10","12"]:
    x = 'x_' + i
    ro = 'ro_' + i
    rou = 'rou_' + i
    rov = 'rov_' + i
    roE = 'roE_' + i
"""

x_02, ro_02, rou_02, rov_02, roE_02 = np.loadtxt( fname='restart0000_2000_02.dat', unpack=True )
x_04, ro_04, rou_04, rov_04, roE_04 = np.loadtxt( fname='restart0000_2000_04.dat', unpack=True )
x_06, ro_06, rou_06, rov_06, roE_06 = np.loadtxt( fname='restart0000_2000_06.dat', unpack=True )
x_08, ro_08, rou_08, rov_08, roE_08 = np.loadtxt( fname='restart0000_2000_08.dat', unpack=True )
x_10, ro_10, rou_10, rov_10, roE_10 = np.loadtxt( fname='restart0000_2000_10.dat', unpack=True )
x_12, ro_12, rou_12, rov_12, roE_12 = np.loadtxt( fname='restart0000_2000_12.dat', unpack=True )

gamma = 1.4
rinf  = 1.0
pinf  = 1e5
uinf  = np.sqrt(pinf/rinf)

u_02 = rou_02/ro_02
u_04 = rou_04/ro_04
u_06 = rou_06/ro_06
u_08 = rou_08/ro_08
u_10 = rou_10/ro_10
u_12 = rou_12/ro_12

p_02 = (gamma-1)*(roE_02 - 0.5*ro_02*u_02**2)
p_04 = (gamma-1)*(roE_04 - 0.5*ro_04*u_04**2)
p_06 = (gamma-1)*(roE_06 - 0.5*ro_06*u_06**2)
p_08 = (gamma-1)*(roE_08 - 0.5*ro_08*u_08**2)
p_10 = (gamma-1)*(roE_10 - 0.5*ro_10*u_10**2)
p_12 = (gamma-1)*(roE_12 - 0.5*ro_12*u_12**2)








# ----------------------------Density-------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)

fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
ax.plot(x_ex, r_ex, color='grey', ls='-' ) #trace rho
#ax.plot(x_ex, p_ex, color='grey', ls='-' )
#ax.plot(x_ex, u_ex, color='grey', ls='-' )

ax.plot(x_02, ro_02/rinf, color='royalblue'     , ls='--', label=r' 2nd order STD',linewidth = 1)
ax.plot(x_04, ro_04/rinf, color='darkviolet'     , ls='--', label=r' 4th order STD',linewidth = 1)
ax.plot(x_06, ro_06/rinf, color='r'     , ls='--', label=r' 6th order STD',linewidth = 1)#'firebrick'
ax.plot(x_08, ro_08/rinf, color='orange'     , ls='--', label=r' 8th order STD',linewidth = 1)
ax.plot(x_10, ro_10/rinf, color='limegreen'     , ls='--', label=r' 10th order STD',linewidth = 1)
ax.plot(x_12, ro_12/rinf, color='darkblue'     , ls='--', label=r' 12th order STD',linewidth = 1)
#ax.plot(x,  p/pinf, color='orange', ls='--', label=r'$p$')
#ax.plot(x,  u/uinf, color='b'     , ls='--', label=r'$u$')
ax.set_title('Numerical results against analytical solution - Density')
ax.set_xlabel(r'$x$',fontsize=24)
ax.set_ylabel(r'$\rho$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_density.png")
plt.close()


# ------------------------pressure----------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)

fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
#ax.plot(x_ex, r_ex, color='grey', ls='-' ) #trace rho
ax.plot(x_ex, p_ex, color='grey', ls='-' )
#ax.plot(x_ex, u_ex, color='grey', ls='-' )

ax.plot(x_02, p_02/pinf, color='royalblue'     , ls='--', label=r' 2nd order STD',linewidth = 1)
ax.plot(x_04, p_04/pinf, color='darkviolet'     , ls='--', label=r' 4th order STD',linewidth = 1)
ax.plot(x_06, p_06/pinf, color='r'     , ls='--', label=r' 6th order STD',linewidth = 1)#'firebrick'
ax.plot(x_08, p_08/pinf, color='orange'     , ls='--', label=r' 8th order STD',linewidth = 1)
ax.plot(x_10, p_10/pinf, color='limegreen'     , ls='--', label=r' 10th order STD',linewidth = 1)
ax.plot(x_12, p_12/pinf, color='darkblue'     , ls='--', label=r' 12th order STD',linewidth = 1)
#ax.plot(x,  p/pinf, color='orange', ls='--', label=r'$p$')
#ax.plot(x,  u/uinf, color='b'     , ls='--', label=r'$u$')
ax.set_title('Numerical results against analytical solution - Pressure')
ax.set_xlabel(r'$x$',fontsize=24)
ax.set_ylabel(r'$p$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_pressure.png")
plt.close()
# ------------------------velocity----------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)

fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
#ax.plot(x_ex, r_ex, color='grey', ls='-' ) #trace rho
#ax.plot(x_ex, p_ex, color='grey', ls='-' )
ax.plot(x_ex, u_ex, color='grey', ls='-' )

ax.plot(x_02, u_02/uinf, color='royalblue'     , ls='--', label=r' 2nd order STD',linewidth = 1)
ax.plot(x_04, u_04/uinf, color='darkviolet'     , ls='--', label=r' 4th order STD',linewidth = 1)
ax.plot(x_06, u_06/uinf, color='r'     , ls='--', label=r' 6th order STD',linewidth = 1)#'firebrick'
ax.plot(x_08, u_08/uinf, color='orange'     , ls='--', label=r' 8th order STD',linewidth = 1)
ax.plot(x_10, u_10/uinf, color='limegreen'     , ls='--', label=r' 10th order STD',linewidth = 1)
ax.plot(x_12, u_12/uinf, color='darkblue'     , ls='--', label=r' 12th order STD',linewidth = 1)
#ax.plot(x,  p/pinf, color='orange', ls='--', label=r'$p$')
#ax.plot(x,  u/uinf, color='b'     , ls='--', label=r'$u$')
ax.set_title('Numerical results against analytical solution - Velocity')
ax.set_xlabel(r'$x$',fontsize=24)
ax.set_ylabel(r'$p$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_velocity.png")
