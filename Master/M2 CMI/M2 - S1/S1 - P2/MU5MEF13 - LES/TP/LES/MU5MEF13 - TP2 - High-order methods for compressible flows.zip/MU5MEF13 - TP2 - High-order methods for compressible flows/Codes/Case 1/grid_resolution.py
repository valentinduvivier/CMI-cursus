
#!/usr/bin/env python3
import glob, os, sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

x_50, ro_50, rou_50, rov_50, roE_50 = np.loadtxt( fname='restart50_2000.dat', unpack=True )
x_200, ro_200, rou_200, rov_200, roE_200 = np.loadtxt( fname='restart200_2000.dat', unpack=True )
x_1000, ro_1000, rou_1000, rov_1000, roE_1000 = np.loadtxt( fname='restart1000_2000.dat', unpack=True )

gamma = 1.4
rinf  = 1.0
pinf  = 1e5
uinf  = np.sqrt(pinf/rinf)

u_50 = rou_50/ro_50
p_50 = (gamma-1)*(roE_50 - 0.5*ro_50*u_50**2)

u_200 = rou_200/ro_200
p_200 = (gamma-1)*(roE_200 - 0.5*ro_200*u_200**2)

u_1000 = rou_1000/ro_1000
p_1000 = (gamma-1)*(roE_1000 - 0.5*ro_1000*u_1000**2)

# ------------------------------------------------------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)



fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
ax.plot(x_ex, r_ex, color='grey', ls='-' )


ax.plot(x_50, ro_50/rinf, color='r'     , ls='--', label=r'$\rho 50$')
ax.plot(x_200,  ro_200/rinf, color='orange', ls='--', label=r'$\rho 200$')
ax.plot(x_1000,  ro_1000/rinf, color='b'     , ls='--', label=r'$\rho 1000$')

ax.set_xlabel(r'$x$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_rho.pdf")





fig2 = plt.figure(2,figsize=(8,6))
ax = fig2.add_subplot(111)

ax.plot(x_ex, p_ex, color='grey', ls='-' )


ax.plot(x_50, p_50/pinf, color='r'     , ls='--', label=r'$p 50$')
ax.plot(x_200,  p_200/pinf, color='orange', ls='--', label=r'$p 200$')
ax.plot(x_1000,  p_1000/pinf, color='b'     , ls='--', label=r'$p 1000$')

ax.set_xlabel(r'$x$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_p.pdf")






fig3 = plt.figure(3,figsize=(8,6))
ax = fig3.add_subplot(111)

ax.plot(x_ex, u_ex, color='grey', ls='-' )

ax.plot(x_50, u_50/uinf, color='r'     , ls='--', label=r'$u 50$')
ax.plot(x_200,  u_200/uinf, color='orange', ls='--', label=r'$u 200$')
ax.plot(x_1000,  u_1000/uinf, color='b'     , ls='--', label=r'$u 1000$')

ax.set_xlabel(r'$x$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_u.pdf")
