#!/usr/bin/env python3
import glob, os, sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

"""for i in ["02","04","06","08","10","12"]:
    x = 'x_' + i
    ro = 'ro_' + i
    rou = 'rou_' + i
    rov = 'rov_' + i
    roE = 'roE_' + i
"""

x_12, ro_12, rou_12, rov_12, roE_12 = np.loadtxt( fname='restart0000_2000_12.dat', unpack=True )
x_12_DRP, ro_12_DRP, rou_12_DRP, rov_12_DRP, roE_12_DRP = np.loadtxt( fname='restart0000_2000_12_DRP.dat', unpack=True )

x_10, ro_10, rou_10, rov_10, roE_10 = np.loadtxt( fname='restart0000_2000_10.dat', unpack=True )
x_10_DRP, ro_10_DRP, rou_10_DRP, rov_10_DRP, roE_10_DRP = np.loadtxt( fname='restart0000_2000_10_DRP.dat', unpack=True )

x_06, ro_06, rou_06, rov_06, roE_06 = np.loadtxt( fname='restart0000_2000_06.dat', unpack=True )
x_06_DRP, ro_06_DRP, rou_06_DRP, rov_06_DRP, roE_06_DRP = np.loadtxt( fname='restart0000_2000_06_DRP.dat', unpack=True )




gamma = 1.4
rinf  = 1.0
pinf  = 1e5
uinf  = np.sqrt(pinf/rinf)

u_12 = rou_12/ro_12
u_12_DRP = rou_12_DRP/ro_12_DRP
p_12 = (gamma-1)*(roE_12 - 0.5*ro_12*u_12**2)
p_12_DRP = (gamma-1)*(roE_12_DRP - 0.5*ro_12_DRP*u_12_DRP**2)

u_10 = rou_10/ro_10
u_10_DRP = rou_10_DRP/ro_10_DRP
p_10 = (gamma-1)*(roE_10 - 0.5*ro_10*u_10**2)
p_10_DRP = (gamma-1)*(roE_10_DRP - 0.5*ro_10_DRP*u_10_DRP**2)

u_06 = rou_06/ro_06
u_06_DRP = rou_06_DRP/ro_06_DRP
p_06 = (gamma-1)*(roE_06 - 0.5*ro_06*u_06**2)
p_06_DRP = (gamma-1)*(roE_06_DRP - 0.5*ro_06_DRP*u_06_DRP**2)







# ----------------------------Density-------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)

fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
ax.plot(x_ex, r_ex, color='grey', ls='-' ) #trace rho
#ax.plot(x_ex, p_ex, color='grey', ls='-' )
#ax.plot(x_ex, u_ex, color='grey', ls='-' )

ax.plot(x_12, ro_12/rinf, color='royalblue'     , ls='--', label=r' 12th order STD',linewidth = 1)
ax.plot(x_12_DRP, ro_12_DRP/rinf, color='darkviolet'     , ls='--', label=r' 12th order DRP',linewidth = 1)

ax.plot(x_10, ro_10/rinf, color='red'     , ls='--', label=r' 10th order STD',linewidth = 1)
ax.plot(x_10_DRP, ro_10_DRP/rinf, color='orange'     , ls='--', label=r' 10th order DRP',linewidth = 1)


ax.plot(x_06, ro_06/rinf, color='black'     , ls='--', label=r' 6th order STD',linewidth = 1)
ax.plot(x_06_DRP, ro_06_DRP/rinf, color='green'     , ls='--', label=r' 6th order DRP',linewidth = 1)


#ax.plot(x,  p/pinf, color='orange', ls='--', label=r'$p$')
#ax.plot(x,  u/uinf, color='b'     , ls='--', label=r'$u$')
ax.set_title('DRP and STD comparison  - Density')
ax.set_xlabel(r'$x$',fontsize=24)
ax.set_ylabel(r'$\rho$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_density_DRP_STD.png")
plt.close()


# ------------------------pressure----------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)

fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
#ax.plot(x_ex, r_ex, color='grey', ls='-' ) #trace rho
ax.plot(x_ex, p_ex, color='grey', ls='-' )
#ax.plot(x_ex, u_ex, color='grey', ls='-' )

ax.plot(x_12, p_12/pinf, color='royalblue'     , ls='--', label=r' 12th order STD',linewidth = 1)
ax.plot(x_12_DRP, p_12_DRP/pinf, color='darkviolet'     , ls='--', label=r' 12th order DRP',linewidth = 1)

ax.plot(x_10, p_10/pinf, color='red'     , ls='--', label=r' 10th order STD',linewidth = 1)
ax.plot(x_10_DRP, p_10_DRP/pinf, color='orange'     , ls='--', label=r' 10th order DRP',linewidth = 1)

ax.plot(x_06, p_06/pinf, color='black'     , ls='--', label=r' 6th order STD',linewidth = 1)
ax.plot(x_06_DRP, p_06_DRP/pinf, color='green'     , ls='--', label=r' 6th order DRP',linewidth = 1)

#ax.plot(x,  p/pinf, color='orange', ls='--', label=r'$p$')
#ax.plot(x,  u/uinf, color='b'     , ls='--', label=r'$u$')
ax.set_title('DRP and STD comparison - Pressure')
ax.set_xlabel(r'$x$',fontsize=24)
ax.set_ylabel(r'$p$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_pressure_DRP_STD.png")
plt.close()
# ------------------------velocity----------------------------------
# Prepare figures
plt.rc('xtick',labelsize=22)
plt.rc('ytick',labelsize=22)
# plt.rc('text',usetex=True)

x_ex, r_ex, p_ex, u_ex, c_ex = np.loadtxt(fname='REF/sod_exact.dat', skiprows=10, unpack=True)

fig1 = plt.figure(1,figsize=(8,6))
ax = fig1.add_subplot(111)
#ax.plot(x_ex, r_ex, color='grey', ls='-' ) #trace rho
#ax.plot(x_ex, p_ex, color='grey', ls='-' )
ax.plot(x_ex, u_ex, color='grey', ls='-' )

ax.plot(x_12, u_12/uinf, color='royalblue'     , ls='--', label=r' 12th order STD',linewidth = 1)
ax.plot(x_12_DRP, u_12_DRP/uinf, color='darkviolet'     , ls='--', label=r' 12th order DRP',linewidth = 1)

ax.plot(x_10, u_10/uinf, color='red'     , ls='--', label=r' 10th order STD',linewidth = 1)
ax.plot(x_10_DRP, u_10_DRP/uinf, color='orange'     , ls='--', label=r' 10th order DRP',linewidth = 1)

ax.plot(x_10, u_10/uinf, color='black'     , ls='--', label=r' 10th order STD',linewidth = 1)
ax.plot(x_10_DRP, u_10_DRP/uinf, color='green'     , ls='--', label=r' 10th order DRP',linewidth = 1)





#ax.plot(x,  p/pinf, color='orange', ls='--', label=r'$p$')
#ax.plot(x,  u/uinf, color='b'     , ls='--', label=r'$u$')
ax.set_title('DRP and STD comparison  - Velocity')
ax.set_xlabel(r'$x$',fontsize=24)
ax.set_ylabel(r'$p$',fontsize=24)
plt.legend(loc=0,fontsize='x-large')
plt.tight_layout()
plt.savefig("shock_tube_velocity_DRP_STD.png")
